export const BRAND_NAME= 'EDRS'
export const DATE_FORMAT= 'YYYY-MM-DD'
export const DATE_TIME_FORMAT= 'YYYY-MM-DDTHH:mm:ss'
export const FORM_ERROR ="Validation errors"