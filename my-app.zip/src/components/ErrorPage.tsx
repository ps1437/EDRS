import React from 'react'

export default function ErrorPage() {
  return (
    <div className="flex text-md text-center p-4 space-y-2">Failed to load the resources , Please try  later !!</div>
  
  )
}
